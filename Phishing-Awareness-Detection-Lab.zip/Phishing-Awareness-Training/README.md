# Phishing Awareness Training

A professional beginner-friendly cybersecurity awareness and detection lab built with Python and Flask. It includes five learning lessons, a 10-question quiz, an offline URL checker, and an email-text checker.

## Learning objectives

By completing this module, learners should be able to:
1. Explain what phishing is and what attackers want.
2. Identify warning signs in suspicious emails.
3. inspect links and recognize lookalike or fake websites.
4. Explain common social engineering tactics.
5. Choose safe actions when a suspicious message is received.

## Technologies used

- Python 3
- Flask (web framework)
- HTML5 and Jinja2 templates
- CSS3
- JavaScript (small interface enhancements)
- pytest (automated tests)

## Project structure

```text
Phishing-Awareness-Training/
├── app.py
├── detector.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── lesson.html
│   ├── quiz.html
│   ├── results.html
│   ├── 404.html
│   └── scanner.html
├── static/
│   ├── style.css
│   └── script.js
├── practice/
│   ├── phishing-scenarios.md
│   ├── answer-key.md
│   └── scanner-test-cases.md
└── tests/
    ├── test_app.py
    └── test_detector.py
```

## Run on Kali Linux / Ubuntu

### 1. Extract and enter the project folder

```bash
unzip Phishing-Awareness-Training.zip
cd Phishing-Awareness-Training
```

### 2. Create a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate
```

If `venv` is unavailable:

```bash
sudo apt update
sudo apt install python3-venv
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the training module

```bash
python app.py
```

Open this address in your browser:

`http://127.0.0.1:5000`

Select **Detection Lab** in the top navigation, or open `http://127.0.0.1:5000/scanner` directly.

Stop the server with `Ctrl + C`.

## Run automated tests

Keep the virtual environment active and run:

```bash
pytest -v
```

The tests check training pages, quiz flow, URL analysis rules, email warning signs, and empty-input handling.

## Training module contents

- Introduction to phishing
- Recognizing suspicious emails
- Fake websites and unsafe links
- Social engineering tactics: urgency, authority, fear, curiosity, and familiarity
- Prevention and incident response best practices
- 10-question interactive knowledge check with explanations\n- Offline practice worksheet with five fictional message scenarios and a separate answer key

## Detection lab

Open **Detection Lab** from the navigation bar.

- **Website URL:** paste a URL and review protocol, domain, IP-address, shortening-service, and other common warning indicators.
- **Email message:** enter the sender, optional Reply-To address, subject, and body. The checker looks for sender mismatches, urgency, credential requests, suspicious phrases, links, and risky attachment names.

The scanner is rule-based and educational. It does not use threat-intelligence feeds, DNS reputation, malware analysis, or machine learning. It can produce false positives and false negatives. A low-risk result is not proof that content is safe.

## Ethical and safety note

All examples in this project are fictional and designed for awareness education. The project does not send emails, collect credentials, visit submitted websites, download files, clone real websites, or perform attacks. Do not paste real passwords, OTPs, or confidential messages. Use the training to build safe habits and follow your organization's security reporting process.

## Suggested demonstration

1. Open the home page and explain the learning objectives.
2. Open each lesson and discuss its warning signs.
3. Complete the quiz using a mix of correct and incorrect answers.
4. Review the score and explanations.
5. Run `pytest -v` to demonstrate that the application is tested.

## Author

**Shahbaz Bhutta**  
Cybersecurity Learner | Python | Security Awareness
