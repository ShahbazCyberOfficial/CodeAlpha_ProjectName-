"""
Phishing Awareness Training
A beginner-friendly Flask learning module with an interactive knowledge check.
Run locally: python app.py
"""
import os
from flask import Flask, render_template, request, session, redirect, url_for
from detector import analyze_url, analyze_email

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY", "local-training-only-change-this-before-deployment"
)

LESSONS = [
    {
        "title": "What is phishing?",
        "body": "Phishing is a social engineering attack in which an attacker pretends to be a trusted person or organization to trick someone into revealing information, opening a harmful attachment, or visiting a fake website.",
        "tips": [
            "Attackers often imitate banks, delivery companies, employers, or popular online services.",
            "The message may arrive by email, text message, phone call, or social media.",
            "The goal may be to steal passwords, payment details, identity information, or access to an account."
        ]
    },
    {
        "title": "Recognizing suspicious emails",
        "body": "Do not judge an email by its logo or display name. Check the sender address, the request, the links, and the attachment before taking action.",
        "tips": [
            "Look for an unexpected request, urgent deadline, threat, prize, or unusual payment instruction.",
            "Check the full sender address, not only the display name.",
            "Hover over a link on a computer to preview its destination; do not click to test it.",
            "Be cautious with unexpected attachments, especially executable or macro-enabled files.",
            "Notice unusual wording, but remember that well-written messages can also be phishing."
        ]
    },
    {
        "title": "Fake websites and unsafe links",
        "body": "A fake website may copy the design of a real service. A padlock or HTTPS connection only encrypts the connection; it does not prove that the website is genuine.",
        "tips": [
            "Read the domain name carefully, including spelling and extra words.",
            "Reach important services using a saved bookmark or by typing the known address yourself.",
            "Do not enter credentials after following an unexpected email or text link.",
            "Never rely on a padlock icon alone to decide whether a site is trustworthy."
        ]
    },
    {
        "title": "Social engineering tactics",
        "body": "Social engineering manipulates people rather than exploiting only a technical weakness. Attackers use emotions and familiar situations to influence decisions.",
        "tips": [
            "Urgency: 'Act now or your account will be closed.'",
            "Authority: pretending to be a manager, bank, police officer, or IT support.",
            "Fear: claiming there is a security problem or unpaid bill.",
            "Curiosity or reward: offering an unexpected prize, document, or delivery update.",
            "Familiarity: impersonating a colleague, friend, or supplier."
        ]
    },
    {
        "title": "What should you do?",
        "body": "Pause and verify before responding. Use a separate trusted channel to confirm unusual requests, and report suspicious messages through your organization's approved process.",
        "tips": [
            "Do not reply, click, download, or share sensitive information until verified.",
            "Contact the sender using a known phone number or saved contact—not the details in the suspicious message.",
            "Report the message to your IT/security team or email provider.",
            "If you entered a password, change it immediately from the genuine website and enable multi-factor authentication.",
            "If you opened a suspicious file, disconnect from the network if instructed by your organization and contact IT support."
        ]
    }
]

QUESTIONS = [
    {
        "question": "An email says your account will be disabled in 10 minutes unless you sign in through its link. What is the safest response?",
        "options": ["Click quickly to avoid losing access", "Open the service using its known official address and check your account", "Reply with your password"],
        "answer": 1,
        "explanation": "Urgency is a common pressure tactic. Verify through a trusted route rather than the message link."
    },
    {
        "question": "Which detail is most useful when checking who sent an email?",
        "options": ["The sender's display name only", "The company logo", "The full sender email address and domain"],
        "answer": 2,
        "explanation": "Display names and logos can be copied. Inspect the full sender address and verify unexpected requests."
    },
    {
        "question": "A website shows a padlock and HTTPS. Does that prove it is genuine?",
        "options": ["Yes, every HTTPS site is trustworthy", "No, HTTPS protects the connection but does not prove the site's identity is legitimate", "Only if the page has a logo"],
        "answer": 1,
        "explanation": "HTTPS is important, but criminals can also use HTTPS on fake websites."
    },
    {
        "question": "Your manager emails asking you to urgently buy gift cards and send the codes. What should you do?",
        "options": ["Buy them immediately", "Verify the request using a separate known contact method", "Forward the codes to the email address"],
        "answer": 1,
        "explanation": "This may be an impersonation or business email compromise attempt. Verify unusual financial requests out-of-band."
    },
    {
        "question": "Which is an example of social engineering?",
        "options": ["A person pretending to be IT support to ask for your one-time code", "A computer installing a normal update", "A printer running out of paper"],
        "answer": 0,
        "explanation": "The attacker uses a false identity and trust to manipulate a person into revealing a secret."
    },
    {
        "question": "What should you do with an unexpected attachment?",
        "options": ["Open it to see what it is", "Forward it to friends", "Verify with the sender through a trusted channel and follow security policy"],
        "answer": 2,
        "explanation": "Unexpected attachments can contain malware or lead to credential theft. Verify before opening."
    },
    {
        "question": "You entered your password on a page that now looks fake. What is a good first step?",
        "options": ["Ignore it", "Change the password through the genuine service and report the incident", "Send the password to the sender to confirm"],
        "answer": 1,
        "explanation": "Change exposed credentials using the genuine website, enable MFA, and notify the appropriate support team."
    },
    {
        "question": "Which URL should make you pause?",
        "options": ["A bookmarked official website", "A domain with misspellings or extra words that imitates a known brand", "A website address you typed from a trusted source"],
        "answer": 1,
        "explanation": "Lookalike domains are commonly used to make fake websites appear legitimate."
    },
    {
        "question": "A text message says a parcel is held and asks for a small unexpected fee through a link. What is safest?",
        "options": ["Pay through the link", "Check tracking using the delivery company's official app or website", "Send your card details by text"],
        "answer": 1,
        "explanation": "Delivery-themed messages are common lures. Verify directly with the delivery provider."
    },
    {
        "question": "What is the best general habit when a message asks for sensitive information?",
        "options": ["Pause, verify independently, and report if suspicious", "Trust it if the message looks professional", "Share information if the sender sounds confident"],
        "answer": 0,
        "explanation": "A pause-and-verify habit helps defeat urgency, impersonation, and fake-link tactics."
    }
]

@app.get("/")
def index():
    return render_template("index.html", lessons=LESSONS)

@app.route("/scanner", methods=["GET", "POST"])
def scanner():
    result = None
    mode = request.form.get("mode", "url")
    if request.method == "POST":
        if mode == "email":
            result = analyze_email(request.form.get("sender"), request.form.get("reply_to"), request.form.get("subject"), request.form.get("body"))
        else:
            mode = "url"
            result = analyze_url(request.form.get("url"))
    return render_template("scanner.html", result=result, mode=mode)

@app.get("/lesson/<int:lesson_id>")
def lesson(lesson_id):
    if lesson_id < 0 or lesson_id >= len(LESSONS):
        return render_template("404.html"), 404
    return render_template("lesson.html", lesson=LESSONS[lesson_id],
                           lesson_id=lesson_id, total=len(LESSONS))

@app.route("/quiz", methods=["GET", "POST"])
def quiz():
    if request.method == "POST":
        answers = {}
        score = 0
        for i, question in enumerate(QUESTIONS):
            raw = request.form.get(f"q{i}", "")
            try:
                selected = int(raw)
            except (TypeError, ValueError):
                selected = -1
            if selected < 0 or selected >= len(question["options"]):
                selected = -1
            answers[i] = selected
            if selected == question["answer"]:
                score += 1
        session["quiz_result"] = {"score": score, "answers": answers}
        return redirect(url_for("results"))
    return render_template("quiz.html", questions=QUESTIONS)

@app.get("/results")
def results():
    result = session.get("quiz_result")
    if not result:
        return redirect(url_for("quiz"))
    review = []
    for i, question in enumerate(QUESTIONS):
        selected = result["answers"].get(str(i), result["answers"].get(i, -1))
        review.append({
            "question": question["question"],
            "selected": selected,
            "correct": question["answer"],
            "correct_text": question["options"][question["answer"]],
            "explanation": question["explanation"],
            "is_correct": selected == question["answer"]
        })
    score = result["score"]
    percent = round(score / len(QUESTIONS) * 100)
    if percent >= 80:
        message = "Great work! You have a strong foundation in phishing awareness."
    elif percent >= 60:
        message = "Good effort. Review the explanations and practice the safety checks."
    else:
        message = "Keep learning. Revisit the lessons and try the quiz again."
    return render_template("results.html", score=score, total=len(QUESTIONS),
                           percent=percent, message=message, review=review)

@app.get("/reset")
def reset():
    session.pop("quiz_result", None)
    return redirect(url_for("quiz"))

@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404

if __name__ == "__main__":
    # Local-only by default. Do not enable debug mode on a public server.
    app.run(host="127.0.0.1", port=5000, debug=False)
