"""Offline heuristic phishing checks. Results are indicators, not proof."""
import ipaddress
import re
from urllib.parse import urlparse

URL_SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy", "shorturl.at"}
SUSPICIOUS_TERMS = {
    "verify your account": 2, "account suspended": 3, "account will be closed": 3,
    "urgent": 1, "immediately": 1, "within 24 hours": 2, "password": 1,
    "one-time code": 3, "otp": 2, "gift card": 3, "wire transfer": 3,
    "payment failed": 2, "claim your prize": 3, "confirm your identity": 2,
    "unusual activity": 1, "click here": 1, "login": 1, "invoice attached": 1,
}

def _rating(score):
    if score >= 6:
        return "High risk", "high", "Several strong warning signs were found. Do not open links or share information."
    if score >= 2:
        return "Potential risk", "medium", "Some warning signs were found. Verify independently before taking action."
    return "Lower risk indicators", "low", "Few warning signs were detected, but this does not prove the content is safe."

def analyze_url(raw_url):
    raw_url = (raw_url or "").strip()
    findings, score = [], 0
    if not raw_url:
        return {"kind":"url", "input":raw_url, "score":0, "level":"unknown", "label":"No URL provided", "summary":"Enter a URL to analyze.", "findings":[]}
    candidate = raw_url if "://" in raw_url else "http://" + raw_url
    try:
        parsed = urlparse(candidate)
        host = (parsed.hostname or "").lower().rstrip(".")
        if not host:
            raise ValueError("Missing hostname")
    except Exception:
        return {"kind":"url", "input":raw_url, "score":0, "level":"high", "label":"Invalid URL", "summary":"The address could not be parsed. Check its format.", "findings":["The URL format is invalid or the hostname is missing."]}
    if parsed.scheme.lower() != "https":
        score += 1
        findings.append("The address does not use HTTPS. This alone does not prove phishing.")
    if parsed.username or parsed.password or "@" in parsed.netloc:
        score += 3
        findings.append("The URL contains user-info or an @ symbol, which can hide the real destination.")
    try:
        ipaddress.ip_address(host.strip("[]"))
        score += 3
        findings.append("The website uses a raw IP address instead of a normal domain.")
    except ValueError:
        pass
    if host.startswith("xn--") or ".xn--" in host:
        score += 2
        findings.append("The domain contains punycode, which can be used in lookalike domains.")
    if host in URL_SHORTENERS:
        score += 2
        findings.append("This is a URL-shortening service, so the final destination is hidden.")
    if len(host) > 35 or host.count(".") >= 4:
        score += 1
        findings.append("The domain is unusually long or has many subdomains.")
    if re.search(r"(login|verify|secure|account|update|confirm|wallet|bank)", host):
        score += 1
        findings.append("The domain contains words often used in deceptive login or verification links.")
    if re.search(r"%(?:2e|2f|40)", raw_url.lower()):
        score += 1
        findings.append("The URL contains encoded special characters; inspect it carefully.")
    try:
        if parsed.port and parsed.port not in (80, 443):
            score += 1
            findings.append(f"The URL uses a non-standard port ({parsed.port}).")
    except ValueError:
        score += 2
        findings.append("The URL contains an invalid port number.")
    label, level, summary = _rating(score)
    if not findings:
        findings.append("No common URL warning patterns were detected by these basic checks.")
    return {"kind":"url", "input":raw_url, "score":score, "level":level, "label":label, "summary":summary, "findings":findings, "hostname":host, "scheme":parsed.scheme.lower()}

def analyze_email(sender, reply_to, subject, body):
    fields = {"sender":(sender or "").strip(), "reply_to":(reply_to or "").strip(), "subject":(subject or "").strip(), "body":(body or "").strip()}
    combined = " ".join(fields.values()).lower()
    findings, score = [], 0
    if not any(fields.values()):
        return {"kind":"email", "score":0, "level":"unknown", "label":"No email content", "summary":"Enter at least one email field to analyze.", "findings":[]}
    if fields["sender"] and "@" not in fields["sender"]:
        score += 2
        findings.append("The sender address does not look like a normal email address.")
    if fields["reply_to"] and fields["sender"]:
        sender_domain = fields["sender"].rsplit("@",1)[-1].lower()
        reply_domain = fields["reply_to"].rsplit("@",1)[-1].lower()
        if "@" in fields["reply_to"] and sender_domain != reply_domain:
            score += 3
            findings.append("The Reply-To domain differs from the sender domain.")
    if fields["sender"] and re.search(r"(gmail|outlook|yahoo)\.com$", fields["sender"].lower().rsplit("@",1)[-1]):
        if re.search(r"(bank|microsoft|google|paypal|amazon|apple|support)", fields["sender"].lower()):
            score += 2
            findings.append("A consumer email domain appears to be posing as a well-known organization.")
    for term, points in SUSPICIOUS_TERMS.items():
        if term in combined:
            score += points
            findings.append(f"Message contains a pressure or sensitive-request phrase: “{term}”.")
    links = re.findall(r"https?://[^\s<>]+", fields["body"], flags=re.I)
    if links:
        score += min(2, len(links))
        findings.append(f"The message contains {len(links)} URL(s). Inspect each destination separately before opening.")
    if re.search(r"\.(zip|exe|scr|js|vbs|iso|docm|xlsm)", fields["body"], re.I):
        score += 2
        findings.append("The message mentions a potentially risky or macro-enabled attachment.")
    label, level, summary = _rating(score)
    if not findings:
        findings.append("No common warning phrases or sender mismatches were detected by these basic checks.")
    return {"kind":"email", "score":score, "level":level, "label":label, "summary":summary, "findings":findings, "urls":links}
