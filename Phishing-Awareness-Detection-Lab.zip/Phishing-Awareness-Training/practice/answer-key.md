# Practice File — Answer Key

Use this only after completing `phishing-scenarios.md`.

1. **Scenario 1: Likely phishing.** Warning signs: short deadline, threat of account closure, request for a password through a message link. Safest action: do not use the link; open the mailbox through its known official address and report the message if suspicious.

2. **Scenario 2: Needs independent verification / likely phishing.** Warning signs: unexpected delivery problem and a fee request through a message link. Safest action: check tracking using the delivery company's official app or website, not the message link.

3. **Scenario 3: Likely legitimate, but context matters.** It contains no unusual request or link and appears to come from a known colleague's usual address. Still verify if the change is unexpected or inconsistent with normal work communication.

4. **Scenario 4: Likely phishing.** Warning signs: impersonation risk, urgency, gift-card payment, secrecy, and request for redeemable codes. Safest action: do not buy or send codes; verify using a separate known phone number or in person and report it.

5. **Scenario 5: Likely legitimate security notification, but verify independently.** It does not ask the user to click a link or share a password. Safest action: use the official app or saved bookmark to check account activity and secure the account if the reset was not requested.

**Reflection answers**
- Scenario 1 uses urgency and fear.
- Scenario 4 uses authority, urgency, and secrecy.
- A known official app/bookmark avoids relying on a potentially deceptive message link.
- If a password was entered on a suspicious page, change it immediately through the genuine service, enable MFA, review account activity, and report it to the relevant support/security team.
