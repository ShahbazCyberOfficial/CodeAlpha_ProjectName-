# Phishing Awareness Practice File

**Name:** ____________________  
**Date:** ____________________

## Instructions
Read each fictional message. Do not click anything or contact any address shown here. These examples use reserved `.example` domains and are for classroom practice only.

For each scenario, decide:
- **Likely phishing**
- **Likely legitimate**
- **Needs independent verification**

Then write down the warning signs and the safest next action.

---

## Scenario 1 — Urgent account warning

**From:** Account Support `<security-alert@accounts-example.example>`  
**Subject:** Your mailbox will be closed in 15 minutes

Your mailbox will be permanently disabled unless you confirm your password immediately using the button below.

**Your decision:** ____________________  
**Warning signs:**  
1. __________________________________  
2. __________________________________  
**Safest next action:** __________________________________

## Scenario 2 — Unexpected delivery fee

**From:** Parcel Updates `<updates@parcel-example.example>`  
**Subject:** Delivery attempt unsuccessful

We could not deliver your parcel. A small redelivery fee is required. Please review the tracking details through the link in this message.

**Your decision:** ____________________  
**Warning signs:**  
1. __________________________________  
2. __________________________________  
**Safest next action:** __________________________________

## Scenario 3 — Routine meeting notice

**From:** Your known colleague using their usual company address  
**Subject:** Team meeting moved to 2:00 PM

Hi, today's team meeting has moved from 1:30 PM to 2:00 PM. The meeting room is unchanged. Thanks.

**Your decision:** ____________________  
**Warning signs or reassuring details:**  
1. __________________________________  
2. __________________________________  
**Safest next action:** __________________________________

## Scenario 4 — Manager asks for gift cards

**From:** “Managing Director” `<director.office@example-mail.example>`  
**Subject:** Confidential — urgent request

I am in a meeting and cannot talk. Buy five gift cards and send me the codes immediately. Do not tell anyone because this is confidential.

**Your decision:** ____________________  
**Warning signs:**  
1. __________________________________  
2. __________________________________  
**Safest next action:** __________________________________

## Scenario 5 — Password reset you did not request

**From:** Identity Service `<no-reply@identity-example.example>`  
**Subject:** Password reset requested

A password reset was requested for your account. If you did not request this, open the service using its official app or a saved bookmark and review your account security.

**Your decision:** ____________________  
**Warning signs or reassuring details:**  
1. __________________________________  
2. __________________________________  
**Safest next action:** __________________________________

---

## Final reflection

1. Which scenario used urgency or fear?  
   ______________________________________________________

2. Which scenario used authority or secrecy?  
   ______________________________________________________

3. Why is it safer to open a service through its known official app or bookmarked address?  
   ______________________________________________________

4. What should you do if you already entered your password on a suspicious page?  
   ______________________________________________________
