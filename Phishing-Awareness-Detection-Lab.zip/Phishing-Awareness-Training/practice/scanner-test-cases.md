# Phishing Detection Lab — Test Cases

Use these fictional examples to check the URL and email scanner. The `.test` domain and documentation-only IP addresses are reserved for examples. Do not replace them with real targets unless you have permission.

## A. Website URL tests

| Input | Expected result | Why |
|---|---|---|
| `https://example.com/` | Lower risk indicators | No common warning pattern should be found |
| `http://192.0.2.10/login` | Potential risk | HTTP plus a raw IP address |
| `https://bit.ly/example` | Potential risk | Shortened URL warning should appear |
| `https://xn--pple-43d.com/login` | Potential risk | Punycode and login-related domain wording |
| `http://example.com:8443/login` | Potential risk | Non-standard port and login-related wording |

Note: The scanner uses a points-based heuristic. Exact risk levels may change if its rules are updated; check the findings as well as the label.

## B. Email tests

### Test 1 — Suspicious account warning

**Sender:** `security@example.test`  
**Reply-To:** *(leave blank)*  
**Subject:** `Urgent: account suspended`  
**Body:**
```text
Your account will be closed. Verify your account immediately.
Enter your password to restore access.
```
Expected: **High risk**. Look for urgency, account suspension, verification, and password wording.

### Test 2 — Reply-To mismatch

**Sender:** `help@company.test`  
**Reply-To:** `reply@other.test`  
**Subject:** `A quick update`  
**Body:**
```text
Please review the attached information when you have time.
```
Expected: **Potential risk**. The sender and Reply-To domains differ.

### Test 3 — Suspicious payment request

**Sender:** `accounts@example.test`  
**Reply-To:** *(leave blank)*  
**Subject:** `Payment failed — action required`  
**Body:**
```text
Your payment failed. Click here immediately to confirm your identity:
http://192.0.2.20/verify
```
Expected: **High risk**. Look for payment pressure, urgency, a link, and a raw-IP URL in the message.

### Test 4 — Ordinary meeting notice

**Sender:** `colleague@example.test`  
**Reply-To:** *(leave blank)*  
**Subject:** `Team meeting moved to 2 PM`  
**Body:**
```text
Hello, our team meeting has moved to 2 PM today.
Please use the calendar invitation already on your work account.
```
Expected: **Lower risk indicators**. No common warning phrase should be detected. This does not prove the message is genuine.

## C. How to run a test

1. Start the Flask app.
2. Open `http://127.0.0.1:5000/scanner`.
3. Select **Website URL** and test each URL above.
4. Select **Email message** and enter the sample sender, Reply-To, subject, and body.
5. Compare the scanner findings with the expected results above.

## Important limitation

This is a beginner-level rule-based detector, not a professional threat-intelligence service. It does not check domain registration, DNS records, certificates, website content, malware, sender authentication (SPF/DKIM/DMARC), or live reputation. It can miss phishing and can flag legitimate messages. Never treat a low-risk label as proof of safety.
