// Small usability enhancement: mark a selected quiz answer.
document.addEventListener("change", function (event) {
  if (event.target.matches('.option input[type="radio"]')) {
    const group = event.target.name;
    document.querySelectorAll('input[name="' + group + '"]').forEach(function (input) {
      input.closest(".option").classList.toggle("selected", input.checked);
    });
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll(".tab-button[data-mode]");
  const urlForm = document.getElementById("url-form");
  const emailForm = document.getElementById("email-form");
  tabs.forEach((tab) => tab.addEventListener("click", () => {
    const emailMode = tab.dataset.mode === "email";
    urlForm.hidden = emailMode; emailForm.hidden = !emailMode;
    tabs.forEach((item) => item.classList.toggle("active", item === tab));
  }));
});
