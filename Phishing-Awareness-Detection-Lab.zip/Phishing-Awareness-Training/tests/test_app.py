import sys
from pathlib import Path

# Make the project root importable when pytest is run from the repository.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import app, QUESTIONS

def setup_function():
    app.config["TESTING"] = True
    app.config["SECRET_KEY"] = "test-secret"

def test_home_page_loads():
    response = app.test_client().get("/")
    assert response.status_code == 200
    assert b"Think before" in response.data

def test_all_lessons_load():
    client = app.test_client()
    for lesson_id in range(5):
        assert client.get(f"/lesson/{lesson_id}").status_code == 200

def test_invalid_lesson_returns_404():
    assert app.test_client().get("/lesson/99").status_code == 404

def test_quiz_page_loads():
    response = app.test_client().get("/quiz")
    assert response.status_code == 200
    assert b"KNOWLEDGE CHECK" in response.data

def test_quiz_submission_and_results():
    client = app.test_client()
    payload = {f"q{i}": str(q["answer"]) for i, q in enumerate(QUESTIONS)}
    response = client.post("/quiz", data=payload, follow_redirects=True)
    assert response.status_code == 200
    assert b"10 / 10 correct" in response.data

def test_quiz_reset_redirects_to_quiz():
    client = app.test_client()
    response = client.get("/reset")
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/quiz")


def test_scanner_page_loads():
    response = app.test_client().get("/scanner")
    assert response.status_code == 200
    assert b"Phishing Detection Lab" in response.data

def test_url_scanner_form_returns_findings():
    response = app.test_client().post("/scanner", data={"mode": "url", "url": "http://192.0.2.10/login"})
    assert response.status_code == 200
    assert b"Potential risk" in response.data

def test_email_scanner_form_returns_high_risk():
    response = app.test_client().post("/scanner", data={"mode": "email", "sender": "security@example.test", "reply_to": "", "subject": "Urgent account suspended", "body": "Verify your account immediately. Enter your password."})
    assert response.status_code == 200
    assert b"High risk" in response.data
