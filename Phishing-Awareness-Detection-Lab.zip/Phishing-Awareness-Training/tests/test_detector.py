from detector import analyze_url, analyze_email

def test_url_detects_raw_ip_and_http():
    result = analyze_url("http://192.0.2.10/login")
    assert result["level"] == "medium"
    assert any("IP address" in item for item in result["findings"])

def test_url_handles_missing_scheme():
    result = analyze_url("example.com")
    assert result["hostname"] == "example.com"

def test_email_detects_urgent_credential_request():
    result = analyze_email("security@example.test", "", "Urgent account suspended", "Verify your account immediately. Enter your password.")
    assert result["level"] == "high"

def test_email_detects_reply_to_mismatch():
    result = analyze_email("help@company.test", "reply@other.test", "Hello", "Please review.")
    assert any("Reply-To domain differs" in item for item in result["findings"])

def test_empty_inputs_are_handled():
    assert analyze_url("")["level"] == "unknown"
    assert analyze_email("", "", "", "")["level"] == "unknown"
