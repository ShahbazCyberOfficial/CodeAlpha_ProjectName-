# Secure Coding Review — Task 3

A small, local Python/Flask application used to demonstrate a defensive secure-coding review.
It includes an intentionally insecure training version, a safer version, a Bandit scan script,
manual review findings, and a remediation report.

## Requirements
- Python 3.10+
- Linux (tested workflow uses a virtual environment)

## Run on Linux
```bash
cd secure_coding_review
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app_secure.py
```
Open `http://127.0.0.1:5000` in your browser. This demo binds to localhost only.

## Run the static analyzer
```bash
source .venv/bin/activate
bandit -r . -x .venv
```
Or:
```bash
chmod +x run_bandit.sh
./run_bandit.sh
```

## Compare the training examples
- `training/insecure_examples.py` contains deliberately unsafe patterns for review.
- `app_secure.py` demonstrates safer alternatives.
- `docs/SECURITY_REVIEW_REPORT.md` documents findings, severity, and remediation.

**Safety note:** The insecure examples are deliberately simplified, local training material.
Do not deploy them or expose them to a network. Use `app_secure.py` for the runnable demo.
