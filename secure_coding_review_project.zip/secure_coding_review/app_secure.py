"""Safer local demo application for the Secure Coding Review assignment."""
import os
import sqlite3
from pathlib import Path

from flask import Flask, abort, jsonify, request

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "demo.db"

app = Flask(__name__)
# In production, load a long random secret from the deployment environment/secret manager.
app.config["SECRET_KEY"] = os.environ.get("APP_SECRET_KEY")
app.config["DEBUG"] = False


def init_db():
    """Create a tiny local demo database with parameterized SQL."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS notes "
            "(id INTEGER PRIMARY KEY, title TEXT NOT NULL)"
        )
        conn.execute(
            "INSERT INTO notes(title) SELECT ? "
            "WHERE NOT EXISTS (SELECT 1 FROM notes WHERE title = ?)",
            ("Welcome", "Welcome"),
        )


@app.get("/")
def home():
    return jsonify({
        "application": "Secure Coding Review Demo",
        "status": "running",
        "endpoints": ["/api/notes", "/health"],
    })


@app.get("/health")
def health():
    return jsonify({"status": "ok"})


@app.get("/api/notes")
def search_notes():
    """Search notes safely; user input is passed as a SQL parameter."""
    term = request.args.get("q", "")
    if len(term) > 100:
        abort(400, description="Search term is too long")
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            "SELECT id, title FROM notes WHERE title LIKE ? ORDER BY id LIMIT ?",
            (f"%{term}%", 50),
        ).fetchall()
    return jsonify([{"id": row[0], "title": row[1]} for row in rows])


if __name__ == "__main__":
    init_db()
    # Localhost-only binding keeps this classroom demo off the network.
    app.run(host="127.0.0.1", port=5000, debug=False)
