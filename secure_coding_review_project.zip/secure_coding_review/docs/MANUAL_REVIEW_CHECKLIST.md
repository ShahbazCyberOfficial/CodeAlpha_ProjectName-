# Manual Review Checklist

- [ ] Are SQL queries parameterized?
- [ ] Are secrets absent from source code and version control?
- [ ] Is debug mode disabled outside local development?
- [ ] Is untrusted input validated and length-limited?
- [ ] Are database results bounded?
- [ ] Does the demo bind only to localhost?
- [ ] Are dependencies pinned to reviewed version ranges?
- [ ] Are errors handled without exposing internal details?
- [ ] Are logs free of passwords, tokens, and sensitive data?
- [ ] Are authorization checks applied to protected actions?
