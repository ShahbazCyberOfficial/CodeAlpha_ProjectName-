# Security Review Report

## 1. Project overview
**Application:** Secure Coding Review Demo  
**Language:** Python  
**Framework:** Flask  
**Database:** SQLite  
**Review methods:** Manual source inspection and Bandit static analysis.

The runnable application is `app_secure.py`. Deliberately unsafe examples are isolated in
`training/insecure_examples.py` so the reviewer can compare insecure and secure patterns.

## 2. Scope and method
The review inspected SQL query construction, secret handling, debug configuration, input
validation, database access, and network binding. Bandit is included as a static-analysis
tool. Run it with `./run_bandit.sh` after installing requirements.

## 3. Findings

| ID | Finding | Risk | Evidence / impact | Remediation |
|---|---|---|---|---|
| F-01 | SQL query concatenation | High | `training/insecure_examples.py` builds SQL using untrusted input. This can change query meaning. | Use parameterized queries. `app_secure.py` passes values separately to `execute()`. |
| F-02 | Hard-coded secret | High | A secret stored in source can leak through source control or shared files. | Load secrets from environment variables or a secrets manager; rotate exposed secrets. |
| F-03 | Debug mode enabled | Medium | Debug configuration may expose internal details and should not be enabled in production. | Keep debug disabled in deployment; use controlled server-side logging. |
| F-04 | Unbounded input | Medium | Very long search strings can waste resources and degrade service. | Validate input length and reject oversized values. |
| F-05 | Broad network exposure | Medium | A development demo exposed on all interfaces may be reachable by other devices. | Bind local training demos to `127.0.0.1`; apply network controls in real deployments. |

## 4. Secure coding practices demonstrated
- Parameterized SQL instead of string concatenation.
- No real credentials embedded in source code.
- Debug mode disabled.
- Basic input length validation.
- Bounded query results.
- Localhost-only binding for the classroom demo.
- Clear separation between intentionally insecure examples and runnable safe code.

## 5. Validation
1. Create and activate a Python virtual environment.
2. Install `requirements.txt`.
3. Start `app_secure.py` and visit `/`, `/health`, and `/api/notes`.
4. Run `bandit -r . -x .venv` and review its output.

Static analysis is not proof that software is secure. Findings must be reviewed in context,
and a real application also needs dependency checks, authentication/authorization review,
logging review, tests, and deployment configuration review.

## 6. Conclusion
The review identified common coding risks and mapped each to a safer implementation.
The main corrective actions are parameterized database access, externalized secrets,
disabled debug mode, bounded input, and restricted network exposure.
