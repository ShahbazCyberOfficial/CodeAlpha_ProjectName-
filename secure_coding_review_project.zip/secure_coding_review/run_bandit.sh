#!/usr/bin/env bash
set -euo pipefail
python -m bandit -r . -x .venv
