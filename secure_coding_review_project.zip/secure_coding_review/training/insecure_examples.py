"""
INTENTIONALLY INSECURE TRAINING EXAMPLES.
Do not deploy or expose this file. Review the patterns; use app_secure.py instead.
"""
import sqlite3

# Finding example: SQL is built by concatenating untrusted input.
def unsafe_search(db_path, user_term):
    connection = sqlite3.connect(db_path)
    query = "SELECT id, title FROM notes WHERE title LIKE '%" + user_term + "%'"
    return connection.execute(query).fetchall()


# Finding example: credentials/secrets should never be committed to source control.
DEMO_API_SECRET = "replace-this-demo-secret-do-not-use"


# Finding example: debug mode can disclose internal diagnostic information.
# A production server must not run with debug enabled.
DEBUG_CONFIGURATION = {"DEBUG": True}
